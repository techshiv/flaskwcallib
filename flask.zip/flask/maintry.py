import paho.mqtt.client as mqtt
from flask import Flask, render_template, request
import time 
import sqlite3
import json
from flask_socketio import SocketIO, emit


global name
global val
global node1
global node2

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app)

# The callback for when the client receives a CONNACK response from the server.
def on_connect(client, userdata, flags, rc):
    print("Connected with result code "+str(rc))

    # Subscribing in on_connect() means that if we lose the connection and
    # reconnect then subscriptions will be renewed.
    client.subscribe("outTopic")

# The callback for when a PUBLISH message is received from the ESP8266.
def on_message(client, userdata, message):
    #socketio.emit('my variable')
    print("Received message '" + str(message.payload) + "' on topic '"
        + message.topic + "' with QoS " + str(message.qos))
    client.publish('inTopic', 'Message Recieved from other Node')
    y = json.loads(message.payload)
    #print("df")
    #print(y)
    
    for key,value in y.items():
        global name
        global val
        global node1
        global node2
        name=str(key)
        val=str(value)
        #print(name)
        if name=='node1':
            node1=val
            socketio.emit('dht_temperature', {'data': val})
           # print(node1)
                    
        if name=='node2':
            node2=val
            socketio.emit('dht_humidity', {'data': val})
    con = sqlite3.connect('sensr.db')
    cursorObj = con.cursor()
    query = "INSERT INTO "+name+" (val)VALUES("+val+");"
    #print(query)
    cursorObj.execute(query)
    con.commit()
   
    
    
   # print(reading)
    

   
    
   
   
mqttc=mqtt.Client()
mqttc.on_connect = on_connect
mqttc.on_message = on_message
mqttc.connect("localhost",1883,60)
mqttc.loop_start()

@app.route("/")
def main():
    global node1
    # Pass the template data into the template main.html and return it to the user
    return render_template('main.html')


if __name__ == "__main__":
   socketio.run(app, host='0.0.0.0', port=8181)